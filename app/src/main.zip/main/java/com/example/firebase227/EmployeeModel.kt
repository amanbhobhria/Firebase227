package com.example.firebase227



data class EmployeeModel
    (
    var empId: String? = null,
    var empName:String? = null,
    var empAge:String? = null,
    var empSalary:String? = null,
)